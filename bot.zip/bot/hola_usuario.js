var builder = require('botbuilder');
var connector = new builder.ConsoleConnector().listen();

var bot = new builder.UniversalBot(connector);

bot.dialog('/',[//
    function(session){
       builder.Prompt.text(session, '¿como te llamas?';
    },
    function (session, results){
        let msj = result.response;
        session.send('Hola $(msj)');
    }
    
]);